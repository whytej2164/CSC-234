//CSC 234
//M1T1 Gold
//Jamal Whyte
//August 17, 2022

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
  int HumanChoice;
  int HumanDecision;
  int ComputerChoice;
  int ComputerDecisionRound1;
  int ComputerDecisionRound2;
  int ComputerDecisionRound3;
  int ComputerDecisionRound4;
  int ComputerDecisionRound5;
  bool PlayAgainInput=true;
  bool PlayAgainQuestion=true;
  bool input1=true;
  bool input2=true;
  bool input3=true;
  bool input4=true;
  bool input5=true;
  int ComputerWin=0;
  int HumanWin=0;
  int YesOrNo=0;
  
  
  while (YesOrNo<2){
    while(PlayAgainInput=true){
      while (input1==true){
      
      
        cout<<"Round 1"<<endl;
        cout << "Enter the corresponding number for your choice" <<endl;
        cout<< "1.)  Rock"<<endl;
        cout<< "2.)  Paper"<<endl;
        cout<< "3.)  Scissors"<<endl;
        cout<< "4.)  Spock"<<endl<<endl;
  
        cin>> HumanChoice;

        if (HumanChoice<1||HumanChoice>4){
          cout<<endl;
          input1=true;
        }
        if (HumanChoice>=1&&HumanChoice<=4){
          input1=false;
        }
      }


      input1=true;
      

    
      if (HumanChoice ==1){
        HumanDecision =0;
      }

      if (HumanChoice==2){
        HumanDecision=1;
      }

      if(HumanChoice==3){
        HumanDecision=2;
      }

      if(HumanChoice==4){
        HumanDecision=3;
      }
 
      srand(time(0));

      ComputerDecisionRound1=rand()%4;
  

      if (HumanDecision==0&&ComputerDecisionRound1==0){//1
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<< "Your wins: "<<HumanWin<<endl;
        cout<< "Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==1&&ComputerDecisionRound1==1){//2
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==2&&ComputerDecisionRound1==2){//3
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==3){//4
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;
        
      }

      if (HumanDecision==0&&ComputerDecisionRound1==1){//5
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;    
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==0&&ComputerDecisionRound1==2){//6
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==0&&ComputerDecisionRound1==3){//7
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;    
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;
      }

      if(HumanDecision==1&&ComputerDecisionRound1==0){//8
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        

    
      }

      if(HumanDecision==1&&ComputerDecisionRound1==2){//9
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound1==3){//10
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound1==0){//11
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }
 
      if(HumanDecision==2&&ComputerDecisionRound1==1){//12
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound1==3){//13
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

       
      }

      if(HumanDecision==3&&ComputerDecisionRound1==0){//14
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==1){//15
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==2){//16
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

  






  
      while (input2==true){
        cout<<"Round 2"<<endl;
        cout << "Enter the corresponding number for your choice"<<endl;
        cout<< "1.)  Rock"<<endl;
        cout<< "2.)  Paper"<<endl;
        cout<< "3.)  Scissors"<<endl;
        cout<< "4.)  Spock"<<endl<<endl;
  
        cin>> HumanChoice;

        if (HumanChoice<1||HumanChoice>4){
          cout<<endl;
          input2=true;
        }
        if (HumanChoice>=1&&HumanChoice<=4){
          input2=false;
        }
      }

      input2=true;

    
      if (HumanChoice ==1){
        HumanDecision =0;
      }

      if (HumanChoice==2){
        HumanDecision=1;
      }

      if(HumanChoice==3){
        HumanDecision=2;
      }

      if(HumanChoice==4){
        HumanDecision=3;
      }

      srand(time(0));

      ComputerDecisionRound2=rand()%4;
  

      if (HumanDecision==0&&ComputerDecisionRound2==0){//1
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<< "Your wins: "<<HumanWin<<endl;
        cout<< "Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==1&&ComputerDecisionRound2==1){//2
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==2&&ComputerDecisionRound2==2){//3
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;    

        
      }

      if(HumanDecision==3&&ComputerDecisionRound2==3){//4
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;
      }



      

      if (HumanDecision==0&&ComputerDecisionRound2==1){//5
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;   
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==0&&ComputerDecisionRound2==2){//6
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

       
    
      }

      if (HumanDecision==0&&ComputerDecisionRound2==3){//7
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
    
      }
      

      if(HumanDecision==1&&ComputerDecisionRound2==0){//8
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound2==2){//9
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound2==3){//10
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }
    
      

      if(HumanDecision==2&&ComputerDecisionRound2==0){//11
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound2==1){//12
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound2==3){//13
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }



      if(HumanDecision==3&&ComputerDecisionRound1==0){//14
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==1){//15
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==2){//16
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

       
      }


    



      while (input3==true){
        cout<<"Round 3"<<endl;
        cout << "Enter the corresponding number for your choice"<<endl;
        cout<< "1.)  Rock"<<endl;
        cout<< "2.)  Paper"<<endl;
        cout<< "3.)  Scissors"<<endl;
        cout<< "4.)  Spock"<<endl<<endl;



        
  
        cin>> HumanChoice;

        if (HumanChoice<1||HumanChoice>4){
          cout<<endl;
          input3=true;
        }
        if (HumanChoice>=1&&HumanChoice<=4){
          input3=false;
        }
      }

      input3=true;

    
      if (HumanChoice ==1){
        HumanDecision =0;
      }

      if (HumanChoice==2){
        HumanDecision=1;
      }

      if(HumanChoice==3){
        HumanDecision=2;
      }

      if(HumanChoice==4){
        HumanDecision=3;
      }

      srand(time(0));

      ComputerDecisionRound3=rand()%4;
  

      if (HumanDecision==0&&ComputerDecisionRound3==0){//1
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<< "Your wins: "<<HumanWin<<endl;
        cout<< "Computer wins: "<<ComputerWin<<endl<<endl;

        
      } 

      if (HumanDecision==1&&ComputerDecisionRound3==1){//2
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==2&&ComputerDecisionRound3==2){//3
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl; 

        
      }


      if (HumanDecision==3&&ComputerDecisionRound3==3){//4
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl; 

        
      }
      

      if (HumanDecision==0&&ComputerDecisionRound3==1){//5
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;   
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==0&&ComputerDecisionRound3==2){//6
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
    
      }

      if (HumanDecision==0&&ComputerDecisionRound3==3){//7
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
    
      }

      

      if(HumanDecision==1&&ComputerDecisionRound3==0){//8
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

       
      }

      if(HumanDecision==1&&ComputerDecisionRound3==2){//9
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound3==3){//10
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      

      if(HumanDecision==2&&ComputerDecisionRound3==0){//11
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

       
      }

      if(HumanDecision==2&&ComputerDecisionRound3==1){//12
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound3==3){//13
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==0){//14
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==1){//15
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==2){//16
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }





  
      while (input4==true){
        cout<<"Round 4"<<endl;
        cout << "Enter the corresponding number for your choice"<<endl;
        cout<< "1.)  Rock"<<endl;
        cout<< "2.)  Paper"<<endl;
        cout<< "3.)  Scissors"<<endl;
        cout<< "4.)  Spock"<<endl<<endl;
  
        cin>> HumanChoice;

        if (HumanChoice<1||HumanChoice>4){
          cout<<endl;
          input4=true;
        }
        if (HumanChoice>=1&&HumanChoice<=4){
          input4=false;
        }
      }

      input4=true;


    
      if (HumanChoice ==1){
        HumanDecision =0;
      }

      if (HumanChoice==2){
        HumanDecision=1;
      }

      if(HumanChoice==3){
        HumanDecision=2;
      }

      if(HumanChoice==4){
        HumanDecision=3;
      }

      srand(time(0));

      ComputerDecisionRound4=rand()%4;
  

      if (HumanDecision==0&&ComputerDecisionRound4==0){//1
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<< "Your wins: "<<HumanWin<<endl;
        cout<< "Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==1&&ComputerDecisionRound4==1){//2
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==2&&ComputerDecisionRound4==2){//3
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl; 

        
      }

      if (HumanDecision==3&&ComputerDecisionRound4==3){//4
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl; 

        
      }
      

      if (HumanDecision==0&&ComputerDecisionRound4==1){//5
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;   
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==0&&ComputerDecisionRound4==2){//6
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
    
      }

      if (HumanDecision==0&&ComputerDecisionRound4==3){//7
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

       
    
      }


      

      if(HumanDecision==1&&ComputerDecisionRound4==0){//8
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound4==2){//9
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound4==3){//10
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }
      
      

      if(HumanDecision==2&&ComputerDecisionRound4==0){//11
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound4==1){//12
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

       
      } 

      if(HumanDecision==2&&ComputerDecisionRound4==3){//13
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      } 

      if(HumanDecision==3&&ComputerDecisionRound1==0){//14
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==1){//15
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==2){//16
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

  





      while (input5==true){
        cout<<"Round 5"<<endl;
        cout << "Enter the corresponding number for your choice"<<endl;
        cout<< "1.)  Rock"<<endl;
        cout<< "2.)  Paper"<<endl;
        cout<< "3.)  Scissors"<<endl;
        cout<< "4.)  Spock"<<endl<<endl;
  
        cin>> HumanChoice;

        if (HumanChoice<1||HumanChoice>4){
          cout<<endl;
          input5=true;
        }
        if (HumanChoice>=1&&HumanChoice<=4){
          input5=false;
        }
      }

      input5=true;

    
      if (HumanChoice ==1){
        HumanDecision =0;
      }

      if (HumanChoice==2){
        HumanDecision=1;
      }

      if(HumanChoice==3){
        HumanDecision=2;
      }

      if(HumanChoice==4){
        HumanDecision=3;
      }

      srand(time(0));

      ComputerDecisionRound5=rand()%4;
  

      if (HumanDecision==0&&ComputerDecisionRound5==0){//1
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<< "Your wins: "<<HumanWin<<endl;
        cout<< "Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==1&&ComputerDecisionRound5==1){//2
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==2&&ComputerDecisionRound5==2){//3
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;   

        
      }

      if (HumanDecision==3&&ComputerDecisionRound5==3){//4
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"It is a tie"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        HumanWin=HumanWin+1;  
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;   

        
      }

      

      if (HumanDecision==0&&ComputerDecisionRound5==1){//5
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;   
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if (HumanDecision==0&&ComputerDecisionRound5==2){//6
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
    
      }

      if (HumanDecision==0&&ComputerDecisionRound5==3){//7
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
    
      }

      

      if(HumanDecision==1&&ComputerDecisionRound5==0){//8
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound5==2){//9
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==1&&ComputerDecisionRound5==3){//10
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }
      
  
      if(HumanDecision==2&&ComputerDecisionRound5==0){//11
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound5==1){//12
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==2&&ComputerDecisionRound5==3){//13
        cout<<endl;
        cout<<"The computer chose Spock"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==0){//14
        cout<<endl;
        cout<<"The computer chose Rock"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==1){//15
        cout<<endl;
        cout<<"The computer chose Paper"<<endl;
        cout<<"The computer won"<<endl<<endl;
        ComputerWin=ComputerWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }

      if(HumanDecision==3&&ComputerDecisionRound1==2){//16
        cout<<endl;
        cout<<"The computer chose Scissors"<<endl;
        cout<<"You won"<<endl<<endl;
        HumanWin=HumanWin+1;
        cout<<"Your wins: "<<HumanWin<<endl;
        cout<<"Computer wins: "<<ComputerWin<<endl<<endl;

        
      }


      
      
      


      

      if(HumanWin==ComputerWin) {
        cout<<"There is no winner of the series"<<endl;
      } 

      if(HumanWin>ComputerWin){
        cout<<"You are the winner of the series"<<endl;
      }

      if(HumanWin<ComputerWin){
        cout<<"The computer is the winner of the series"<<endl;
      }

      PlayAgainQuestion=true;
      while (PlayAgainQuestion==true){
        cout<<"Would you like to play again?"<<endl;
        cout<<"1.)  Yes"<<endl;
        cout<<"2.)  No"<<endl;
        cin>>YesOrNo;

        if (YesOrNo==1){
          input1=true;
          input2=true;
          input3=true;
          input4=true;
          input5=true;


        
          PlayAgainQuestion=false;
          PlayAgainInput=true;

          ComputerWin=0;
          HumanWin=0;
        }

        if(YesOrNo==2){
           PlayAgainQuestion=false;
           PlayAgainInput=false;
           break;
        }
    
        if(YesOrNo<1||YesOrNo>2){
          PlayAgainQuestion=true;
          PlayAgainInput=false;
      
        }

      

        

      }
    
      if(YesOrNo==2){
        break;
      }

    
      
    }
  }
  


  
  return 0;
}