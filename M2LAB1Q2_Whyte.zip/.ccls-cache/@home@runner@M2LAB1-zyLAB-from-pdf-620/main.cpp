// CSC 234
// M2LAB1 Question 2
// Jamal Whyte
// September 9, 2022

#include <iostream>
#include <iomanip>
using namespace std;

double StepsToMiles(int userSteps){
  double miles;

  miles=userSteps/2000.00;
  
  return miles;
}

int main() {
  int steps;
  double miles;
  
  cout<< fixed<<setprecision(2);
  cout << "Enter the number of steps: ";
  cin>>steps;

  miles=StepsToMiles(steps);

  cout<<"The number of miles walked is: "<<miles;
    
  return 0;
}