//CSC 234
//M2LAB2
//Jamal Whyte
//September 10, 2022

#include <iostream>
using namespace std;

void turnRight();
void turnLeft();
void walkForward();

void turnLeft(){
  int decision;
  
  cout <<"You see a clearing"<<endl;
  cout <<"Choose 1 to turn around and keep walking."<<endl;
  cout <<"Choose 2 to sit down."<<endl;
  cin>> decision;
  cout<<endl;

  if (decision==1){
    turnRight();
  }
    
  if (decision==2){
    cout<<"You give up on reaching your destination today and you spend the night here."<<endl;
    cout<< "GAME OVER";
  }
  
}

void turnRight(){
  int choice;

  cout<<"Choose 1 to turn around and keep walking."<<endl;
  cout<<"Choose 2 to stay here."<<endl;
  cin>>choice;
  cout<<endl;
  
  if (choice==1){
    turnLeft();
  }
  if(choice==2){
    cout<<"You see a lake, but... you don't see the alligator."<<endl;
  cout<<"GAME OVER";
  }
  
}



void walkForward(){
  int choice;
  
  cout<<"Choose 1 to Climb a Tree or"<<endl;
  cout<<"Choose 2 to Walk Left"<<endl;
  cin>> choice;
  cout<<endl;
  
  if (choice==1)
  {
    cout<<"You get a good view of the area.  You will arrive at your destination on time."<<endl;
    cout<<"CONGRATULATIONS, YOU WIN"<<endl;
  }

  if (choice==2){
    cout<<"You get lost"<<endl;
    cout<<"GAME OVER";
  }
    
}

int main() {
  int direction;
  
  cout<<"Welcome to The Forest"<<endl<<endl;
  cout<<"Choose 1 to walk a quarter of a mile Left"<<endl;
  cout<<"Choose 2 to walk a quarter of a mile Right"<<endl;
  cout<<"Choose 3 to walk a quarter of a mile Forward"<<endl;
  
  cin>> direction;
  cout<<endl;

  if (direction ==1){
    turnLeft();
  }

  if (direction==2){
    turnRight();
  }

  if (direction==3){
    walkForward();
  }
  
  return 0;

}