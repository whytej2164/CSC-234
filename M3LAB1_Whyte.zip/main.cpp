//CSC 234
//M1T1
//Jamal Whyte
//October 7, 2022

//Sample Room class with usage
#include <iostream>
using namespace std;

class Room{
public:
  //class fields (variables)
  int id;
  string name;
  string description;

  //class methods (functions)
  Room(){
  };

  Room(int id, string name, string description){
    this ->id=id;
    this ->name=name;
    this ->description=description;
  };

  void describe(){
    //describe the room
    cout<<name<<endl;
    cout<<description<<endl;
  }
};

int main() {
  cout << "Sample room info"<<endl;

  Room garage;
  garage.name="Garage";
  garage.id=1;
  garage.description="A simple 2 car garage.";

  cout<<garage.name<<endl;
  cout<<garage.id<<endl;
  cout<<garage.description<<endl;

  cout<<"next room"<<endl;

  Room attic = Room (2, "Attic", "A large attic.");
  cout<<attic.name<<endl;
  cout<<attic.id<<endl;
  cout<<attic.description<<endl;

  cout<<"next room"<<endl;

  Room livingRoom;
  livingRoom.name="Living Room";
  livingRoom.id=3;
  livingRoom.description="A simple living room with carpet and a couch.";

  cout<<livingRoom.name<<endl;
  cout<<livingRoom.id<<endl;
  cout<<livingRoom.description<<endl;

  

  cout<<"With description function"<<endl;

  garage.describe();
  attic.describe();
  livingRoom.describe();
  
  return 0;
}