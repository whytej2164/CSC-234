//CSC 234
//M1T1
//Jamal Whyte
//October 7, 2022

//Sample Room class with usage
#include <iostream>
using namespace std;

class Room{
public:
  //class fields (variables)
  int id;
  string name;
  string description;

  //class methods (functions)
  Room(){
  };

  Room(int id, string name, string description){
    this ->id=id;
    this ->name=name;
    this ->description;
  };
};

int main() {
  cout << "Sample room info"<<endl;

  Room livingRoom;
  livingRoom.name="Living Room";
  livingRoom.id=1;
  livingRoom.description="A simple living room with carpet and a couch.";

  cout<<livingRoom.name<<endl;
  cout<<livingRoom.id<<endl;
  cout<<livingRoom.description<<endl;

  cout<<"next room"<<endl;

  Room kitchen= Room(2, "kitchen","hjggjhh");

  cout<<kitchen.description;
  //cout<<kitchen.name<<endl;
  //cout<<kitchen.id<<endl;
  //cout<<"hello";
  

  return 0;
}