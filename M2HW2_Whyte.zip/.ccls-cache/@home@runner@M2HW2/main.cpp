//CSC 234
//M2HW2 Gold
//Jamal Whyte
//September 14, 2022

#include <iostream>
#include <iomanip>
using namespace std;

void showMenu();
void addNumbers();
void subtractNumbers();
void divideNumbers();
void multiplyNumbers();

void showMenu(){
  int AddSubtractDivideMultiplyExit;

  cout<<"Welcome to the calculator program."<<endl;
  cout<<"1.  Add"<<endl;
  cout<<"2.  Subtract"<<endl;
  cout<<"3.  Divide"<<endl;
  cout<<"4.  Multiply"<<endl;
  cout<<"5.  Exit"<<endl;
  cout<<"Enter a number: ";
  
  cin>>AddSubtractDivideMultiplyExit;
  cout<<endl;

  if (AddSubtractDivideMultiplyExit ==1){
    addNumbers();
  }

  if (AddSubtractDivideMultiplyExit==2){
    subtractNumbers();
  }

  if (AddSubtractDivideMultiplyExit==3){
    divideNumbers();
  }

  if(AddSubtractDivideMultiplyExit==4){
    multiplyNumbers();
  }

  if(AddSubtractDivideMultiplyExit==5){
    cout<<"Goodbye.";
  }
}

void addNumbers(){
  float num1;
  float num2;
  int AddInput=1;
    
  while (AddInput==1){
    cout<<"Add"<<endl;
    cout<<"Enter a number: ";
    cin>>num1;
    cout<<"Enter a number: ";
    cin>>num2;
    cout<<num1<<" + "<<num2<<" = "<<num1+num2<<endl<<endl;
    cout<<"1.  Repeat"<<endl;
    cout<<"2.  Main Menu"<<endl;
    cout<<"Enter a number: ";
    cin>>AddInput;
    cout<<endl;
    if (AddInput==2){
      showMenu();
    }
  }
}

void subtractNumbers(){
  float number1;
  float number2;
  int SubtractInput=1;

  while(SubtractInput==1){
    cout<<"Subtract"<<endl;
    cout <<"Enter a number: ";
    cin>>number1;
    cout<<"Enter a number: ";
    cin>>number2;
    cout<<number1<<" - "<<number2<< " = "<<number1-number2<<endl<<endl;
    cout<<"1.  Repeat"<<endl;
    cout<<"2.  Main Menu"<<endl;
    cout<<"Enter a number: ";
    cin>>SubtractInput;
    cout<<endl;
    if(SubtractInput==2){
      showMenu();
    }
  }
}

void divideNumbers(){
  float val1;
  float val2;
  int DivideInput=1;

  while(DivideInput==1){
    cout<<"Divide"<<endl;
    cout<<"Enter a number: ";
    cin>>val1;
    cout<<"Enter a number: ";
    cin>>val2;
    cout<<val1<<" / "<<val2<<" = "<<val1/val2<<endl<<endl;
    cout<<"1.  Repeat"<<endl;
    cout<<"2.  Main Menu"<<endl;
    cout<<"Enter a number: ";
    cin>>DivideInput;
    cout<<endl;
    if(DivideInput==2){
      showMenu();  
    }
  }
}  

void multiplyNumbers(){
  float value1;
  float value2;
  int MultiplyInput=1;

  while (MultiplyInput==1){
    cout<<"Multiply"<<endl;
    cout<<"Enter a number: ";
    cin>>value1;
    cout<<"Enter a number: ";
    cin>>value2;
    cout<<value1<<" * "<<value2<<" = "<<value1*value2<<endl<<endl;
    cout<<"1.  Repeat"<<endl;
    cout<<"2.  Main Menu"<<endl;
    cout<<"Enter a number: ";
    cin>>MultiplyInput;
    cout<<endl;
    if(MultiplyInput==2){
      showMenu();
    }
  }
}

int main(){
  cout<<fixed <<setprecision(2);
  showMenu();
  
  return 0;
}



