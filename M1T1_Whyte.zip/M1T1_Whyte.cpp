//CSC 234
//M1T1
//Jamal Whyte
//August 17, 2022
#include <iostream>
using namespace std;

int main() {
  cout << "My name is Jamal Whyte."<<endl;
  cout << "I am studying C++ this semester."<<endl;
  cout << "My hobby is playing video games.";
}