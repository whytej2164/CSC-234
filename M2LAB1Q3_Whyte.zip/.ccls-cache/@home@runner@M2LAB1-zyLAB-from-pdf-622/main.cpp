// CSC 234
// M2LAB1 Question 3
// Jamal Whyte
// September 9, 2022

#include <iostream>
#include <iomanip>
using namespace std;

double DrivingCost(double drivenMiles, double milesPerGallon, double dollarsPerGallon){
  double cost;

  cost=(drivenMiles/milesPerGallon)*(dollarsPerGallon);
  
  return cost;
}

int main() {
  double miles;
  double mpg;
  double dpg;
  double price;
  
  cout<<fixed <<setprecision(2);

  cout<<"Enter the number of miles: ";
  cin>>miles;
  cout<<"Enter the number of miles per gallon: ";
  cin>>mpg;
  cout<<"Enter the amount of gas dollars per gallon: $";
  cin>> dpg;

  price=DrivingCost(miles,mpg,dpg);
  cout<<"The price is: $"<<price<<endl<<endl;
  
  cout<<"Enter the number of miles: ";
  cin>>miles;
  
  price=DrivingCost(miles,mpg,dpg);
  cout<<"The price is: $"<<price<<endl<<endl;
  
  cout<<"Enter the number of miles: ";
  cin>>miles;
  
  price=DrivingCost(miles,mpg,dpg);
  cout<<"The price is: $"<< price<<endl<<endl;
  
  return 0;
}