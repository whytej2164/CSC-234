// CSC 234
// M2LAB1 Question 1
// Jamal Whyte
// September 8, 2022

#include <iostream>
#include <iomanip>
using namespace std;

double MilesToLaps(double userMiles){
  double laps;

  laps=userMiles*4;
    
  return laps;
}
  
int main() {
  double miles;
  double laps;
  
  cout<<setprecision(2) <<fixed<<endl;
  cout<<"Enter the number of miles: ";
  cin>>miles;
  
  laps=MilesToLaps(miles);
  
  cout<<"The number of laps is: "<<laps;

  return 0;
}