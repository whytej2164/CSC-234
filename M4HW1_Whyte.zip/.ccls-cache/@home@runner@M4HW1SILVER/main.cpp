#include <iostream>
#include <string>
using namespace std;

class Room{
   public: 
      string name;
      string description;
      Room *next;
      Room *previous;
      void InsertAfter(Room *nodeLoc);
      void PrintNodeData();
      Room();
      Room (string PlaceName, string PlaceDescription, string PlaceExits, Room *nextLoc, Room *previousLoc);
     // Room *GetNext();   
      string exits;
      Room * GetAndPrintNext();
      void Before();
};

Room::Room() {
		this->name = "";
		this->description = "";
    this->exits="";
		this->next = nullptr;
    this->previous=nullptr;
}

Room:: Room (string PlaceName, string PlaceDescription, string PlaceExits, Room *nextLoc, Room *previousLoc){
    this ->name=PlaceName;
    this ->description=PlaceDescription;
    this ->exits=PlaceExits;
    this ->next=nextLoc;
    this ->previous=previousLoc;
}

void Room::InsertAfter(Room *nodeLoc){
  Room* tmpNext=nullptr;
  tmpNext=this->next;
  this->next=nodeLoc;
  nodeLoc->next=tmpNext;
}

//void Room::Before(){
//  tmpPrevious=this->previous;
//}

void Room::PrintNodeData(){
  cout<<this->name<<endl;
  cout<<this->description<<endl;
  cout<<"Exits: "<<this->exits<<endl<<endl;
}

Room * Room::GetAndPrintNext(){
  cout<<next->name<<endl;
  cout<<next->description<<endl;
  cout<<"Exits: "<<next->exits<<endl<<endl;
  return this->next;
}

//Room * Room::GetAndPrintPrevious(){
  //cout<<previous->
//}

int main() {
  Room *LivingRoom=nullptr;
  Room *DiningRoom=nullptr;
  Room *Kitchen=nullptr;
  Room *head=nullptr;
  Room *currNode=nullptr;
  int ChooseRoom;
  
    
  head = new Room ();
  
  LivingRoom=new Room();
  LivingRoom->name="Living Room";
  LivingRoom->description="A large living room with a fireplace";
  LivingRoom->exits="north";
  head-> InsertAfter(LivingRoom);

  DiningRoom=new Room();
  DiningRoom->name="Dining Room";
  DiningRoom->description="A large dining room with the table set for dinner";
  DiningRoom->exits="south, east";
  LivingRoom->InsertAfter(DiningRoom);

  Kitchen =new Room();
  Kitchen->name="Kitchen";
  Kitchen->description="A spotless kitchen";
  Kitchen->exits="west";
  DiningRoom->InsertAfter(Kitchen);
  
  //currNode=head->GetNext();
  //while (currNode!=nullptr){
    //currNode->PrintNodeData();
    //currNode=currNode->GetNext();
  //}

  //currNode->PrintNodeData();

  currNode=head->GetAndPrintNext();
 // LivingRoom->PrintNodeData();
 // DiningRoom->PrintNodeData();
  
  cout<<"Choose"<<endl;
  cout<<"1.  Enter the previous room"<<endl;
  cout<<"2.  Enter the next room"<<endl;
  cin>>ChooseRoom;
  if (ChooseRoom==1){
   // if ()
    currNode->GetAndPrintNext();
    
  }
  if (ChooseRoom==2){
    currNode->GetAndPrintNext();
  } 

//  if (ChooseRoom==2)
  
  return 0;
}