//CSC 234
//M2HW1
//Jamal Whyte
//September 10, 2022

#include <iostream>
using namespace std;

void turnRight(int stick);
int turnLeft(int stick);
void walkForward();
int pickUpStick();
void eightOfMile();

int turnLeft(int stick){
  int decision;

  
  if(stick==1){
    cout<<"You see a man who attacks you.  You hit him with the stick.  Then he runs away."<<endl;
    cout <<"You see a clearing."<<endl;
    cout<<"You sit down."<<endl;
    cout<<"Then get up and you walk an eighth of a mile in the same direction.";
    //decision=2;
    
  }

  if(stick==0){
  
    cout <<"You see a clearing"<<endl;
    cout <<"Choose 1 to turn around and keep walking."<<endl;
    cout <<"Choose 2 to sit down."<<endl;
  
    cin>> decision;
    cout<<endl;
  }
  
  if (decision==1){
    turnRight(stick);
  }
    
  if (decision==2){
      cout<<"You give up on reaching your destination today and you spend the night here."<<endl;
      cout<< "GAME OVER";
  }

  return stick;
}

int pickUpStick(){
  int stick=1;
  
  cout<<"While picking up a stick you notice an alligator nearby.  It attacks.  You are able to fend off the alligator with the stick.  You then turn around and keep walking."<<endl;
  
  turnLeft(stick);
  return stick;
}

void turnRight(int stick){
  int choice;

  cout<<"Choose 1 to turn around and keep walking."<<endl;
  cout<<"Choose 2 to stay here."<<endl;
  cout<<"Choose 3 to pick up a stick"<<endl;
  cin>>choice;
  cout<<endl;
  
  if (choice==1){
    turnLeft(stick);
  }
  if(choice==2){
    cout<<"You see a lake, but... you don't see the alligator."<<endl;
  cout<<"GAME OVER";
  }

  if(choice==3){
    pickUpStick();
  }
  
}



void walkForward(){
  int choice;
  
  cout<<"Choose 1 to Climb a Tree or"<<endl;
  cout<<"Choose 2 to Walk Left"<<endl;
  cin>> choice;
  cout<<endl;
  
  if (choice==1)
  {
    cout<<"You get a good view of the area.  You will arrive at your destination on time."<<endl;
    cout<<"CONGRATULATIONS, YOU WIN"<<endl;
  }

  if (choice==2){
    cout<<"You get lost"<<endl;
    cout<<"GAME OVER";
  }
    
}

int main() {
  int direction;
  int stick=0;
  
  cout<<"Welcome to The Forest"<<endl<<endl;
  cout<<"Choose 1 to walk a quarter of a mile Left"<<endl;
  cout<<"Choose 2 to walk a quarter of a mile Right"<<endl;
  cout<<"Choose 3 to walk a quarter of a mile Forward"<<endl;
  
  cin>> direction;
  cout<<endl;

  if (direction ==1){
    turnLeft(stick);
  }

  if (direction==2){
    turnRight(stick);
  }

  if (direction==3){
    walkForward();
  }
  
  return 0;

}